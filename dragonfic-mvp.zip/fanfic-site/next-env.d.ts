/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: This file should not be edited
